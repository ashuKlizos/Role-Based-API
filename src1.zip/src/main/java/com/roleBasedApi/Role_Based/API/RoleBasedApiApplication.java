package com.roleBasedApi.Role_Based.API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoleBasedApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoleBasedApiApplication.class, args);
	}

}

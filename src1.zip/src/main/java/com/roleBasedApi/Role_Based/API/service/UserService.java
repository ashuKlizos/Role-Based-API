package com.roleBasedApi.Role_Based.API.service;

import com.roleBasedApi.Role_Based.API.dto.UserRequest;
import com.roleBasedApi.Role_Based.API.dto.UserResponse;
import com.roleBasedApi.Role_Based.API.exception.UserExistException;
import com.roleBasedApi.Role_Based.API.exception.UserNotFoundException;
import com.roleBasedApi.Role_Based.API.model.User;
import com.roleBasedApi.Role_Based.API.repository.UserRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;

    }

    public List<UserResponse> getAllUsers() {
        return userRepository.findAll().stream().map(this::convertToDTO).toList();
    }

    public UserResponse getUserById(Integer userId) {

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User with ID " + userId + " not found"));

        UserResponse userResponse = convertToDTO(user);

        return userResponse;
    }



    public UserResponse getUserProfile(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UserNotFoundException("User with username " + username + " not found"));
        return convertToDTO(user);
    }

    public UserResponse createUser(UserRequest user) {
        if (userRepository.findByUsername(user.getUsername()).isPresent()) {
            throw new UserExistException("Already user existed with username");
        }

        // Convert DTO to Entity
        User userEntity = convertToEntity(user);
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        return convertToDTO(userRepository.save(userEntity));
    }


    public void deleteUser(Integer userId) {
        if(getUserById(userId)!=null) {
            userRepository.deleteById(userId);
        }
        throw new UserNotFoundException("User with ID " + userId + " not found");
    }

    //BeanUtils
    //userDto:userResponse

    private UserResponse convertToDTO(User user) {
        UserResponse userResponse = new UserResponse();
        BeanUtils.copyProperties(user, userResponse);
        return userResponse;
    }

    private User convertToEntity(UserRequest userRequest) {
        User user = new User();
        BeanUtils.copyProperties(userRequest, user);
        return user;
    }

}
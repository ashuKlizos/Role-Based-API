package com.roleBasedApi.Role_Based.API.controller;

import com.roleBasedApi.Role_Based.API.model.AuthenticationResponse;
import com.roleBasedApi.Role_Based.API.model.User;
import com.roleBasedApi.Role_Based.API.service.AuthenticationService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthenticationController {

    private final AuthenticationService authService;

    public AuthenticationController(AuthenticationService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public ResponseEntity<AuthenticationResponse> register(
            @Valid @RequestBody User request
    ) {

        return ResponseEntity.ok(authService.register(request));

    }

    @PostMapping("/login")
    public ResponseEntity<AuthenticationResponse> login(
            @RequestBody User request
    ) {

        return ResponseEntity.ok(authService.authenticate(request));
    }

}
package com.roleBasedApi.Role_Based.API.model;

public enum Role {
    USER , ADMIN
}

package com.roleBasedApi.Role_Based.API.exception;

public class UserExistException extends RuntimeException {

    public UserExistException(String message){
        super(message);
    }

}
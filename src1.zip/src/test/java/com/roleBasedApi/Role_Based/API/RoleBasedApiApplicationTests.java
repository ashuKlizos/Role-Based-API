package com.roleBasedApi.Role_Based.API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoleBasedApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
